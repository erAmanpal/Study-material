"""Synthetic RetailMart data for CSE552 Unit VI (Power BI).

Star schema:
  Sales (fact)   - one row per order line, 2025
  Products (dim) - ProductID -> Product, Category
  Stores (dim)   - StoreID -> Store, City, State, Region
  Months (dim)   - MonthNo -> Month name, monthly revenue Target
Also writes RetailMart_PowerBI.xlsx with all four tables as sheets.
Figures are invented for teaching.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(2026)

products = pd.DataFrame([
    ("P01", "Smartphone", "Electronics", 15000), ("P02", "Laptop", "Electronics", 52000),
    ("P03", "Headphones", "Electronics", 2500), ("P04", "Smart Watch", "Electronics", 6000),
    ("P05", "Bluetooth Speaker", "Electronics", 3500),
    ("P06", "Jeans", "Apparel", 1800), ("P07", "Shirt", "Apparel", 1200),
    ("P08", "Kurta", "Apparel", 1500), ("P09", "Sneakers", "Apparel", 3200),
    ("P10", "Jacket", "Apparel", 4000),
    ("P11", "Rice 5kg", "Grocery", 450), ("P12", "Cooking Oil 5L", "Grocery", 900),
    ("P13", "Atta 10kg", "Grocery", 480), ("P14", "Tea 1kg", "Grocery", 520),
    ("P15", "Dry Fruits 1kg", "Grocery", 1100),
    ("P16", "Mixer Grinder", "Home", 3800), ("P17", "Bedsheet Set", "Home", 1600),
    ("P18", "Cookware Set", "Home", 2900), ("P19", "Table Lamp", "Home", 1300),
    ("P20", "Water Purifier", "Home", 9500),
], columns=["ProductID", "Product", "Category", "ListPrice"])
pop = {"Smartphone": 5, "Laptop": 1.2, "Headphones": 4, "Smart Watch": 2.5, "Bluetooth Speaker": 2,
       "Jeans": 6, "Shirt": 7, "Kurta": 5, "Sneakers": 3, "Jacket": 2,
       "Rice 5kg": 9, "Cooking Oil 5L": 8, "Atta 10kg": 9, "Tea 1kg": 7, "Dry Fruits 1kg": 4,
       "Mixer Grinder": 2, "Bedsheet Set": 3, "Cookware Set": 2, "Table Lamp": 2.5, "Water Purifier": 1}
p_prob = np.array([pop[p] for p in products.Product]); p_prob = p_prob / p_prob.sum()

stores = pd.DataFrame([
    ("S01", "RetailMart Ludhiana", "Ludhiana", "Punjab", "North"),
    ("S02", "RetailMart Jalandhar", "Jalandhar", "Punjab", "North"),
    ("S03", "RetailMart Amritsar", "Amritsar", "Punjab", "North"),
    ("S04", "RetailMart Phagwara", "Phagwara", "Punjab", "North"),
    ("S05", "RetailMart Chandigarh", "Chandigarh", "Chandigarh", "North"),
    ("S06", "RetailMart Delhi", "New Delhi", "Delhi", "North"),
    ("S07", "RetailMart Jaipur", "Jaipur", "Rajasthan", "North"),
    ("S08", "RetailMart Mumbai", "Mumbai", "Maharashtra", "West"),
    ("S09", "RetailMart Pune", "Pune", "Maharashtra", "West"),
    ("S10", "RetailMart Ahmedabad", "Ahmedabad", "Gujarat", "West"),
    ("S11", "RetailMart Bengaluru", "Bengaluru", "Karnataka", "South"),
    ("S12", "RetailMart Chennai", "Chennai", "Tamil Nadu", "South"),
    ("S13", "RetailMart Hyderabad", "Hyderabad", "Telangana", "South"),
    ("S14", "RetailMart Kolkata", "Kolkata", "West Bengal", "East"),
    ("S15", "RetailMart Bhubaneswar", "Bhubaneswar", "Odisha", "East"),
], columns=["StoreID", "Store", "City", "State", "Region"])
s_w = np.array([1.6, 1.2, 1.1, 0.8, 1.2, 1.8, 1.0, 1.7, 1.2, 1.1, 1.6, 1.3, 1.3, 1.2, 0.7]); s_w = s_w / s_w.sum()

N = 4000
month_w = np.array([8, 7.5, 8, 7.5, 8, 7, 7.5, 8.5, 8, 12, 11, 9]); month_w = month_w / month_w.sum()
month = rng.choice(np.arange(1, 13), N, p=month_w)
days = np.array([31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31])
day = np.array([rng.integers(1, days[m - 1] + 1) for m in month])
dates = pd.to_datetime({"year": 2025, "month": month, "day": day})
pi = rng.choice(len(products), N, p=p_prob)
qty = np.where(products.Category.values[pi] == "Grocery", rng.integers(1, 5, N), rng.integers(1, 3, N))
price = np.round(products.ListPrice.values[pi] * rng.uniform(0.9, 1.1, N), -1)
disc = rng.choice([0, 0.05, 0.10, 0.15], N, p=[0.5, 0.25, 0.17, 0.08])
sales = pd.DataFrame({
    "OrderID": [f"O{i:05d}" for i in range(1, N + 1)],
    "OrderDate": dates,
    "MonthNo": month,
    "StoreID": rng.choice(stores.StoreID, N, p=s_w),
    "ProductID": products.ProductID.values[pi],
    "Quantity": qty,
    "UnitPrice": price,
    "Discount": disc,
    "PaymentMode": rng.choice(["UPI", "Card", "Cash", "Wallet"], N, p=[0.46, 0.27, 0.17, 0.10]),
}).sort_values("OrderDate").reset_index(drop=True)
sales["OrderID"] = [f"O{i:05d}" for i in range(1, N + 1)]
sales["Revenue"] = (sales.Quantity * sales.UnitPrice * (1 - sales.Discount)).round(2)

monthly = sales.groupby("MonthNo").Revenue.sum()
target = (monthly.mean() * np.array([1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.0, 1.05, 1.05, 1.3, 1.3, 1.15]) / 1e5).round(0) * 1e5
months = pd.DataFrame({"MonthNo": range(1, 13),
                       "Month": ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
                       "Target": target.astype(int)})

prod_out = products.drop(columns="ListPrice")
sales_out = sales.copy(); sales_out["OrderDate"] = sales_out.OrderDate.dt.strftime("%Y-%m-%d")
sales_out.to_csv("Sales.csv", index=False)
prod_out.to_csv("Products.csv", index=False)
stores.to_csv("Stores.csv", index=False)
months.to_csv("Months.csv", index=False)
with pd.ExcelWriter("RetailMart_PowerBI.xlsx") as xw:
    sales.to_excel(xw, sheet_name="Sales", index=False)
    prod_out.to_excel(xw, sheet_name="Products", index=False)
    stores.to_excel(xw, sheet_name="Stores", index=False)
    months.to_excel(xw, sheet_name="Months", index=False)
print(sales.shape, round(sales.Revenue.sum()))
