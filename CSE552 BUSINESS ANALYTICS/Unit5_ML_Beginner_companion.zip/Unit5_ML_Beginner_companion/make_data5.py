"""Synthetic teaching data for CSE552 Unit V (machine learning).

retailmart_churn.csv : 600 RetailMart customers, one row each.
    Three hidden customer types (used to generate the data, NOT included in
    the file) so that k-means has real groups to find. `churned` (1 = left in
    the next 6 months) depends on visits, complaints, tenure, app use and spend.
    A few missing values and a text column are included for the cleaning step.
students.csv : 12-row toy table (hours studied, attendance, passed) used to
    introduce every algorithm on data small enough to see at once.
"""
import numpy as np
import pandas as pd

rng = np.random.default_rng(552)
N = 600

types = rng.choice(["loyal", "regular", "occasional"], N, p=[0.25, 0.45, 0.30])
spec = {  # monthly_spend mean, sd ; visits mean, sd ; tenure range
    "loyal":      (9000, 1800, 9.0, 1.6, (18, 60)),
    "regular":    (4500, 1100, 5.0, 1.3, (6, 48)),
    "occasional": (1800, 600, 1.8, 0.9, (1, 30)),
}
spend, visits, tenure = [], [], []
for t in types:
    ms, ss, mv, sv, (tlo, thi) = spec[t]
    spend.append(max(300, rng.normal(ms, ss)))
    visits.append(max(0, rng.normal(mv, sv)))
    tenure.append(rng.integers(tlo, thi + 1))
spend = np.round(spend, -1)
visits = np.round(visits).astype(int)
tenure = np.array(tenure)

age = rng.integers(18, 66, N)
app_user = (rng.random(N) < np.where(types == "occasional", 0.35, 0.7)).astype(int)
complaints = rng.poisson(np.where(types == "loyal", 0.4, 0.9))
city_tier = rng.choice(["Tier-1", "Tier-2", "Tier-3"], N, p=[0.45, 0.35, 0.20])
items_per_visit = np.round(np.clip(rng.normal(spend / 1500, 0.8), 1, None), 1)
discount_share = np.round(np.clip(rng.normal(np.where(types == "occasional", 0.45, 0.2), 0.1), 0, 0.9), 2)

z = (0.4 - 0.35 * visits + 0.9 * complaints - 0.04 * tenure - 0.8 * app_user
     - 0.00008 * spend + rng.normal(0, 0.6, N))
p = 1 / (1 + np.exp(-z))
churned = (rng.random(N) < p).astype(int)

df = pd.DataFrame({
    "customer_id": [f"C{i:04d}" for i in range(1, N + 1)],
    "age": age,
    "city_tier": city_tier,
    "tenure_months": tenure,
    "monthly_spend": spend,
    "visits_per_month": visits.astype(float),
    "items_per_visit": items_per_visit,
    "discount_share": discount_share,
    "complaints": complaints,
    "app_user": app_user,
    "churned": churned,
})
miss = rng.choice(N, 12, replace=False)
df.loc[miss, "visits_per_month"] = np.nan
df.to_csv("retailmart_churn.csv", index=False)

students = pd.DataFrame({
    "hours":      [1, 2, 2, 3, 4, 5, 5, 6, 7, 8, 9, 10],
    "attendance": [45, 60, 50, 70, 55, 80, 65, 75, 90, 70, 85, 95],
    "passed":     [0, 0, 0, 0, 0, 1, 0, 1, 1, 1, 1, 1],
})
students.to_csv("students.csv", index=False)
print(df.shape, "churn rate:", round(df.churned.mean(), 3))
print(pd.Series(types).value_counts().to_dict())
